#pragma once
class Nodo
{
public:
	int info;
	Nodo* sig;
};

